NOTIFICATION HISTORY - ANDROID STUDIO PROJECT

මෙය Kotlin + Jetpack Compose + Room භාවිතයෙන් සකස් කළ Android Studio project එකකි.

BUILD කරන ආකාරය:
1. ZIP file එක extract කරන්න.
2. Android Studio විවෘත කරන්න.
3. Open තෝරා extract කළ NotificationHistory folder එක තෝරන්න.
4. Gradle Sync අවසන් වනතුරු ඉන්න.
5. Android SDK 35 සහ JDK 17 භාවිතා කරන්න.
6. Run බොත්තම ඔබන්න. නැතිනම් Build > Build APK(s) තෝරන්න.

APP එක භාවිතා කිරීම:
1. App එක open කළ පසු "Enable notification access" ඔබන්න.
2. Android Settings තුළ NotificationHistory app එකට notification access ලබා දෙන්න.
3. App එකට ආපසු එන්න.
4. ඉන්පසු ලැබෙන notifications local Room database එකේ save වේ.
5. Search box එකෙන් title, message හෝ package name සෙවිය හැක.

සටහන්:
- Android notification access එක user විසින් Settings තුළින්ම enable කළ යුතුයි.
- Android විසින් ලබාදෙන notification content පමණක් save වේ.
- පැරණි notifications සියල්ල ලබාගත හැකි බවට සහතිකයක් නැත; service එක enable කළ පසු ලැබෙන notifications capture කරයි.
- Data device එකේ local database එකේ පවතී. මෙම project එකට server එකක් හෝ cloud sync එකක් නැත.
- Release APK එකක් බෙදාහැරීමට පෙර signing configuration එකක් සකස් කරන්න.
