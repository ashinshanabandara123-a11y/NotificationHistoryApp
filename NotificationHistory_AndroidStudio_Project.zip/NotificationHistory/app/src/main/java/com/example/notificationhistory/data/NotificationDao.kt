package com.example.notificationhistory.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Query("""
        SELECT * FROM notifications
        WHERE title LIKE '%' || :query || '%'
           OR text LIKE '%' || :query || '%'
           OR packageName LIKE '%' || :query || '%'
        ORDER BY timestamp DESC
    """)
    fun searchNotifications(query: String): Flow<List<NotificationEntity>>

    @Query("DELETE FROM notifications WHERE timestamp < :cutoffTime")
    suspend fun deleteOlderThan(cutoffTime: Long)

    @Query("DELETE FROM notifications")
    suspend fun clearAll()
}
