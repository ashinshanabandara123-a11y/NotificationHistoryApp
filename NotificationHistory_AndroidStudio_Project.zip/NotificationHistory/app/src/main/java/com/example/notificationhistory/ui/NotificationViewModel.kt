package com.example.notificationhistory.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.notificationhistory.data.NotificationDatabase
import com.example.notificationhistory.data.NotificationEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class NotificationViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = NotificationDatabase.getDatabase(application).notificationDao()
    private val searchQuery = MutableStateFlow("")

    val notifications = searchQuery.flatMapLatest { query ->
        if (query.isBlank()) dao.getAllNotifications()
        else dao.searchNotifications(query.trim())
    }

    fun search(query: String) {
        searchQuery.value = query
    }

    fun clearAll() {
        viewModelScope.launch { dao.clearAll() }
    }

    fun clearHistoryOlderThan(cutoffTime: Long) {
        viewModelScope.launch { dao.deleteOlderThan(cutoffTime) }
    }
}
